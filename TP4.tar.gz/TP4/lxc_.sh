#!/bin/bash


#sudo lxc launch ubuntu:20.04 R1
#sudo lxc launch ubuntu:20.04 R2
#sudo lxc launch ubuntu:20.04 R3
#sudo lxc launch ubuntu:20.04 C2
#sudo lxc launch ubuntu:20.04 DHCP
#sudo lxc launch ubuntu:20.04 C1
#sudo lxc launch ubuntu:20.04 DNSMAITRE
#sudo lxc launch ubuntu:20.04 C3
#sudo lxc launch ubuntu:20.04 DNSSECONDAIRE

#lxc network create br12 ipv4.dhcp=false ipv6.dhcp=false
#lxc network create br23 ipv4.dhcp=false ipv6.dhcp=false
#lxc network create br13 ipv4.dhcp=false ipv6.dhcp=false

#lxc exec C1 -- apt update
#lxc exec C1 -- apt install isc-dhcp-client

#lxc exec C2 -- apt update
#lxc exec C2 -- apt install isc-dhcp-client

#lxc exec C3 -- apt update
#lxc exec C3 -- apt install isc-dhcp-client


#lxc exec R1 -- apt update
#lxc exec R1 -- apt install isc-dhcp-relay -y

#lxc exec R2 -- apt update
#lxc exec R2 -- apt install isc-dhcp-relay -y

#lxc exec R3 -- apt update
#lxc exec R3 -- apt install isc-dhcp-relay -y

#lxc exec DHCP -- lxc apt install isc-dhcp-server
#lxc exec DNSMASTER -- lxc apt install bind9
#lxc exec DNSSECONDAIRE -- lxc apt install bind9
 
#lxc network create br12 ipv4.address=none ipv6.address=none
#lxc network create br23 ipv4.address=none ipv6.address=none
#lxc network create br13 ipv4.address=none ipv6.address=none

#lxc network attach br12 R1 eth1
#lxc network attach br12 R2 eth1
#lxc network attach br13 R1 eth2
#lxc network attach br13 R3 eth1
#lxc network attach br23 R2 eth2
#lxc network attach br23 R3 eth2

lxc exec R1 -- netplan apply
lxc exec R2 -- netplan apply
lxc exec R3 -- netplan apply
lxc exec DHCP -- netplan apply
lxc exec DNSMAITRE -- netplan apply
lxc exec DNSSECONDAIRE -- netplan apply


#lxc config device add R1 eth1 nic \
#    nictype=bridged parent=lxdbr0 

#lxc config device add CON eth1 nic name=eth1 nictype=bridged parent=lxdbr0
